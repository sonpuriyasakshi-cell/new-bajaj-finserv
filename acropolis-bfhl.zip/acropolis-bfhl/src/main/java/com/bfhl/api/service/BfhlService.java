package com.bfhl.api.service;

import com.bfhl.api.dto.BfhlRequestDTO;
import com.bfhl.api.dto.BfhlResponseDTO;

public interface BfhlService {

    /**
     * Processes the input data array and returns categorized response.
     *
     * @param request the request containing the data array
     * @return BfhlResponseDTO with categorized numbers, alphabets, special chars, etc.
     */
    BfhlResponseDTO processData(BfhlRequestDTO request);
}
