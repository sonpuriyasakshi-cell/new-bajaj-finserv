package com.bfhl.api.service;

import com.bfhl.api.dto.BfhlRequestDTO;
import com.bfhl.api.dto.BfhlResponseDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BfhlServiceImpl implements BfhlService {

    // ================================================================
    //  🔴 CHANGE THESE TO YOUR ACTUAL DETAILS
    // ================================================================
    private static final String FULL_NAME    = "john_doe";       // lowercase, underscore separated
    private static final String DOB          = "17091999";       // ddmmyyyy
    private static final String EMAIL        = "john@xyz.com";
    private static final String ROLL_NUMBER  = "ABCD123";
    // ================================================================

    private static final String USER_ID = FULL_NAME + "_" + DOB;

    @Override
    public BfhlResponseDTO processData(BfhlRequestDTO request) {

        List<String> data = request.getData();

        List<String> oddNumbers       = new ArrayList<>();
        List<String> evenNumbers      = new ArrayList<>();
        List<String> alphabets        = new ArrayList<>();
        List<String> specialCharacters = new ArrayList<>();
        int sum = 0;

        for (String item : data) {
            if (item == null || item.isEmpty()) {
                continue;
            }

            if (isNumeric(item)) {
                // It's a number
                int num = Integer.parseInt(item);
                sum += num;
                if (num % 2 == 0) {
                    evenNumbers.add(item);
                } else {
                    oddNumbers.add(item);
                }
            } else if (isAlphabetic(item)) {
                // It's purely alphabetical → convert to uppercase
                alphabets.add(item.toUpperCase());
            } else {
                // Special character(s)
                specialCharacters.add(item);
            }
        }

        // Build concat_string:
        // Concatenate all alphabetical characters from the input in reverse order,
        // then apply alternating caps (first char uppercase, second lowercase, etc.)
        String concatString = buildConcatString(data);

        // Build response
        BfhlResponseDTO response = new BfhlResponseDTO();
        response.setIsSuccess(true);
        response.setUserId(USER_ID);
        response.setEmail(EMAIL);
        response.setRollNumber(ROLL_NUMBER);
        response.setOddNumbers(oddNumbers);
        response.setEvenNumbers(evenNumbers);
        response.setAlphabets(alphabets);
        response.setSpecialCharacters(specialCharacters);
        response.setSum(String.valueOf(sum));
        response.setConcatString(concatString);

        return response;
    }

    /**
     * Builds the concat_string:
     * 1. Collect all individual alphabetical characters from ALL items in the data array
     * 2. Reverse the order
     * 3. Apply alternating caps: index 0 = uppercase, index 1 = lowercase, etc.
     *
     * Example C: data = ["A", "ABCD", "DOE"]
     *   All chars: A, A, B, C, D, D, O, E
     *   Reversed:  E, O, D, D, C, B, A, A
     *   Alt caps:  E, o, D, d, C, b, A, a  → "EoDdCbAa"
     */
    private String buildConcatString(List<String> data) {
        // Step 1: Collect all alphabetical characters in order
        StringBuilder allChars = new StringBuilder();
        for (String item : data) {
            if (item == null) continue;
            for (char c : item.toCharArray()) {
                if (Character.isLetter(c)) {
                    allChars.append(c);
                }
            }
        }

        // Step 2: Reverse
        String reversed = allChars.reverse().toString();

        // Step 3: Alternating caps (index 0 = upper, index 1 = lower, ...)
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < reversed.length(); i++) {
            char c = reversed.charAt(i);
            if (i % 2 == 0) {
                result.append(Character.toUpperCase(c));
            } else {
                result.append(Character.toLowerCase(c));
            }
        }

        return result.toString();
    }

    /**
     * Checks if a string is a valid integer (including negative numbers).
     */
    private boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) return false;
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if a string contains ONLY alphabetical characters.
     */
    private boolean isAlphabetic(String str) {
        if (str == null || str.isEmpty()) return false;
        for (char c : str.toCharArray()) {
            if (!Character.isLetter(c)) {
                return false;
            }
        }
        return true;
    }
}
