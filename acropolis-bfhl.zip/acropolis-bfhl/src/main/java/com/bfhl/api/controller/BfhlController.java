package com.bfhl.api.controller;

import com.bfhl.api.dto.BfhlRequestDTO;
import com.bfhl.api.dto.BfhlResponseDTO;
import com.bfhl.api.dto.ErrorResponseDTO;
import com.bfhl.api.service.BfhlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bfhl")
public class BfhlController {

    private final BfhlService bfhlService;

    @Autowired
    public BfhlController(BfhlService bfhlService) {
        this.bfhlService = bfhlService;
    }

    /**
     * POST /bfhl
     * Accepts a JSON body with a "data" array and returns categorized response.
     */
    @PostMapping
    public ResponseEntity<?> processData(@RequestBody BfhlRequestDTO request) {
        try {
            if (request.getData() == null || request.getData().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ErrorResponseDTO(false, "Data array is required and cannot be empty."));
            }

            BfhlResponseDTO response = bfhlService.processData(request);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponseDTO(false, "Internal server error: " + e.getMessage()));
        }
    }

    /**
     * GET /bfhl — simple health check
     */
    @GetMapping
    public ResponseEntity<?> healthCheck() {
        return ResponseEntity.ok(
                java.util.Map.of(
                        "status", "API is running",
                        "route", "/bfhl",
                        "method", "POST"
                )
        );
    }
}
