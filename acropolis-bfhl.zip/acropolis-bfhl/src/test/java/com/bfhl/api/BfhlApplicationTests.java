package com.bfhl.api;

import com.bfhl.api.dto.BfhlRequestDTO;
import com.bfhl.api.dto.BfhlResponseDTO;
import com.bfhl.api.service.BfhlService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class BfhlApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BfhlService bfhlService;

    @Autowired
    private ObjectMapper objectMapper;

    // =============================================
    //  SERVICE LAYER TESTS
    // =============================================

    /**
     * Example A from PDF:
     * Input:  ["a", "1", "334", "4", "R", "$"]
     * Expected: odd=["1"], even=["334","4"], alphabets=["A","R"],
     *           special=["$"], sum="339", concat="Ra"
     */
    @Test
    void testExampleA_ServiceLayer() {
        BfhlRequestDTO request = new BfhlRequestDTO(Arrays.asList("a", "1", "334", "4", "R", "$"));
        BfhlResponseDTO response = bfhlService.processData(request);

        assertTrue(response.isIsSuccess());
        assertEquals(List.of("1"), response.getOddNumbers());
        assertEquals(List.of("334", "4"), response.getEvenNumbers());
        assertEquals(List.of("A", "R"), response.getAlphabets());
        assertEquals(List.of("$"), response.getSpecialCharacters());
        assertEquals("339", response.getSum());
        assertEquals("Ra", response.getConcatString());
    }

    /**
     * Example B from PDF:
     * Input:  ["2", "a", "y", "4", "&", "-", "*", "5", "92", "b"]
     * Expected: odd=["5"], even=["2","4","92"], alphabets=["A","Y","B"],
     *           special=["&","-","*"], sum="103", concat="ByA"
     */
    @Test
    void testExampleB_ServiceLayer() {
        BfhlRequestDTO request = new BfhlRequestDTO(
                Arrays.asList("2", "a", "y", "4", "&", "-", "*", "5", "92", "b")
        );
        BfhlResponseDTO response = bfhlService.processData(request);

        assertTrue(response.isIsSuccess());
        assertEquals(List.of("5"), response.getOddNumbers());
        assertEquals(List.of("2", "4", "92"), response.getEvenNumbers());
        assertEquals(List.of("A", "Y", "B"), response.getAlphabets());
        assertEquals(List.of("&", "-", "*"), response.getSpecialCharacters());
        assertEquals("103", response.getSum());
        assertEquals("ByA", response.getConcatString());
    }

    /**
     * Example C from PDF:
     * Input:  ["A", "ABCD", "DOE"]
     * Expected: odd=[], even=[], alphabets=["A","ABCD","DOE"],
     *           special=[], sum="0", concat="EoDdCbAa"
     */
    @Test
    void testExampleC_ServiceLayer() {
        BfhlRequestDTO request = new BfhlRequestDTO(Arrays.asList("A", "ABCD", "DOE"));
        BfhlResponseDTO response = bfhlService.processData(request);

        assertTrue(response.isIsSuccess());
        assertEquals(Collections.emptyList(), response.getOddNumbers());
        assertEquals(Collections.emptyList(), response.getEvenNumbers());
        assertEquals(List.of("A", "ABCD", "DOE"), response.getAlphabets());
        assertEquals(Collections.emptyList(), response.getSpecialCharacters());
        assertEquals("0", response.getSum());
        assertEquals("EoDdCbAa", response.getConcatString());
    }

    /**
     * Test with only numbers
     */
    @Test
    void testOnlyNumbers() {
        BfhlRequestDTO request = new BfhlRequestDTO(Arrays.asList("1", "2", "3", "4"));
        BfhlResponseDTO response = bfhlService.processData(request);

        assertTrue(response.isIsSuccess());
        assertEquals(List.of("1", "3"), response.getOddNumbers());
        assertEquals(List.of("2", "4"), response.getEvenNumbers());
        assertEquals(Collections.emptyList(), response.getAlphabets());
        assertEquals("10", response.getSum());
        assertEquals("", response.getConcatString());
    }

    /**
     * Test with only special characters
     */
    @Test
    void testOnlySpecialCharacters() {
        BfhlRequestDTO request = new BfhlRequestDTO(Arrays.asList("$", "@", "#"));
        BfhlResponseDTO response = bfhlService.processData(request);

        assertTrue(response.isIsSuccess());
        assertEquals(Collections.emptyList(), response.getOddNumbers());
        assertEquals(Collections.emptyList(), response.getEvenNumbers());
        assertEquals("0", response.getSum());
        assertEquals("", response.getConcatString());
    }

    // =============================================
    //  CONTROLLER / INTEGRATION TESTS
    // =============================================

    /**
     * Test POST /bfhl with Example A
     */
    @Test
    void testPostEndpoint_ExampleA() throws Exception {
        String requestJson = "{\"data\": [\"a\", \"1\", \"334\", \"4\", \"R\", \"$\"]}";

        mockMvc.perform(post("/bfhl")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.is_success").value(true))
                .andExpect(jsonPath("$.user_id").isNotEmpty())
                .andExpect(jsonPath("$.odd_numbers[0]").value("1"))
                .andExpect(jsonPath("$.even_numbers[0]").value("334"))
                .andExpect(jsonPath("$.even_numbers[1]").value("4"))
                .andExpect(jsonPath("$.sum").value("339"))
                .andExpect(jsonPath("$.concat_string").value("Ra"));
    }

    /**
     * Test POST /bfhl with empty data → 400
     */
    @Test
    void testPostEndpoint_EmptyData() throws Exception {
        String requestJson = "{\"data\": []}";

        mockMvc.perform(post("/bfhl")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.is_success").value(false));
    }

    /**
     * Test POST /bfhl with invalid body → 400
     */
    @Test
    void testPostEndpoint_InvalidBody() throws Exception {
        String requestJson = "not a json";

        mockMvc.perform(post("/bfhl")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.is_success").value(false));
    }

    /**
     * Test GET /bfhl health check
     */
    @Test
    void testGetEndpoint_HealthCheck() throws Exception {
        mockMvc.perform(get("/bfhl"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("API is running"));
    }
}
